INSERT INTO `part-db`.`internal` (`keyName`, `keyValue`) VALUES ('dbSubversion', '0');
INSERT INTO `part-db`.`internal` (`keyName`, `keyValue`) VALUES ('dbRevision', '0');
