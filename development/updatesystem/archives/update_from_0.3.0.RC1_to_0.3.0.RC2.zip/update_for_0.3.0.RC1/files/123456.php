<?php
  // Hallo, ich bin die neue lib.php
?>
