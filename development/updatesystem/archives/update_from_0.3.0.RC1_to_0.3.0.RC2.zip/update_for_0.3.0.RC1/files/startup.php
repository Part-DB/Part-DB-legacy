<?php
  // Hallo, ich bin die neue startup.php
?>
